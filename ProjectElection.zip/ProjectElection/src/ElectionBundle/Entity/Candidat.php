<?php

namespace ElectionBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * Candidat
 *
 * @ORM\Table(name="candidat")
 * @ORM\Entity(repositoryClass="ElectionBundle\Repository\CandidatRepository")
 */
class Candidat
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="nom", type="string", length=255, unique=true)
     */
    private $nom;

    /**
     * @var string
     *
     * @ORM\Column(name="sexe", type="string", length=255)
     *
     * @Assert\Regex( pattern="/^[MF]$/", message="Le sexe doit etre M ou F.")
     */
    private $sexe;

    /**
     * @var int
     *
     * @ORM\Column(name="age", type="smallint")
     *
     * @Assert\Regex( pattern="/^[0-9]+$/", message="l'age doit etre numerique.")
     *
     * @Assert\LessThan( value=100, message="lage doit etre inferieur a 100")
     */
    private $age;

    /**
     * @ORM\ManyToOne(targetEntity="ElectionBundle\Entity\Liste", inversedBy="candidats", cascade={"persist"} )
     *
     * @ORM\JoinColumn(onDelete="CASCADE")
     */
    private $liste;


    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set nom
     *
     * @param string $nom
     *
     * @return Candidat
     */
    public function setNom($nom)
    {
        $this->nom = $nom;

        return $this;
    }

    /**
     * Get nom
     *
     * @return string
     */
    public function getNom()
    {
        return $this->nom;
    }

    /**
     * Set sexe
     *
     * @param string $sexe
     *
     * @return Candidat
     */
    public function setSexe($sexe)
    {
        $this->sexe = $sexe;

        return $this;
    }

    /**
     * Get sexe
     *
     * @return string
     */
    public function getSexe()
    {
        return $this->sexe;
    }

    /**
     * Set age
     *
     * @param integer $age
     *
     * @return Candidat
     */
    public function setAge($age)
    {
        $this->age = $age;

        return $this;
    }

    /**
     * Get age
     *
     * @return int
     */
    public function getAge()
    {
        return $this->age;
    }

    /**
     * Set liste
     *
     * @param \ElectionBundle\Entity\Liste $liste
     *
     * @return Candidat
     */
    public function setListe(\ElectionBundle\Entity\Liste $liste = null)
    {
        $this->liste = $liste;

        return $this;
    }

    /**
     * Get liste
     *
     * @return \ElectionBundle\Entity\Liste
     */
    public function getListe()
    {
        return $this->liste;
    }
}
