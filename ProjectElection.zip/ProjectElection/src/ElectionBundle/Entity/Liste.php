<?php

namespace ElectionBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Liste
 *
 * @ORM\Table(name="liste")
 * @ORM\Entity(repositoryClass="ElectionBundle\Repository\ListeRepository")
 */
class Liste
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="nom", type="string", length=255, unique=true)
     */
    private $nom;
    /**
     * @ORM\OneToMany(targetEntity="ElectionBundle\Entity\Candidat", mappedBy="liste", cascade={"persist"} )
     */
    private $candidats;


    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set nom
     *
     * @param string $nom
     *
     * @return Liste
     */
    public function setNom($nom)
    {
        $this->nom = $nom;

        return $this;
    }

    /**
     * Get nom
     *
     * @return string
     */
    public function getNom()
    {
        return $this->nom;
    }
    /**
     * Constructor
     */
    public function __construct()
    {
        $this->candidats = new \Doctrine\Common\Collections\ArrayCollection();
    }

    /**
     * Add candidat
     *
     * @param \ElectionBundle\Entity\Candidat $candidat
     *
     * @return Liste
     */
    public function addCandidat(\ElectionBundle\Entity\Candidat $candidat)
    {
        $this->candidats[] = $candidat;
        $candidat->setListe($this);
        return $this;
    }

    /**
     * Remove candidat
     *
     * @param \ElectionBundle\Entity\Candidat $candidat
     */
    public function removeCandidat(\ElectionBundle\Entity\Candidat $candidat)
    {
        $this->candidats->removeElement($candidat);
    }

    /**
     * Get candidats
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getCandidats()
    {
        return $this->candidats;
    }

    public function __toString()
    {
        // TODO: Implement __toString() method.
        return $this->getNom();
    }
}
