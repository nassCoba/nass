<?php

namespace ElectionBundle\Tests\Controller;

use Symfony\Bundle\FrameworkBundle\Test\WebTestCase;

class CandidatControllerTest extends WebTestCase
{
}
