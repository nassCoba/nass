<?php

namespace ElectionBundle\Tests\Controller;

use Symfony\Bundle\FrameworkBundle\Test\WebTestCase;

class ListeControllerTest extends WebTestCase
{
}
