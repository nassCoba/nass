<?php

namespace ElectionBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ElectionBundle extends Bundle
{
}
