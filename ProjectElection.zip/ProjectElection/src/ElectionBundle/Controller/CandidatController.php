<?php

namespace ElectionBundle\Controller;


use ElectionBundle\Entity\Candidat;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Form\Extension\Core\Type\TextType;


class CandidatController extends Controller
{

    public function indexAction() {
        $em = $this->getDoctrine()->getManager();
        $candidats = $em->getRepository('ElectionBundle:Candidat')->findAll();

        return $this->render('@Election/Candidat/index.html.twig', array(
                'candidats' => $candidats));
    }

    public function newAction(Request $request) {
        $candidat = new Candidat();
        $form = $this->createForm('ElectionBundle\Form\CandidatType', $candidat);
        $form->handleRequest($request);
        if ($form->isSubmitted() && $form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->persist($candidat);
            $em->flush();
            return $this->redirectToRoute('candidat_show',
                    array('id' => $candidat->getId()));
        }
        return $this->render('@Election/Candidat/new.html.twig',
                array('form' => $form->createView()));
    }

    public function showAction($id) {
        $candidat = $this->getCandidat($id);
        return $this->render('@Election/Candidat/show.html.twig',
                array('candidat' => $candidat));
    }

    public function editAction(Request $request, $id) {
        $candidat = $this->getCandidat($id);
        $editForm = $this->createForm('ElectionBundle\Form\CandidatType', $candidat);
        $editForm->handleRequest($request);
        if ($editForm->isSubmitted() && $editForm->isValid()) {
            $this->getDoctrine()->getManager()->flush();
            return $this->redirectToRoute('candidat_edit',
                    array('id' => $candidat->getId()));
        }
        return $this->render('@Election/Candidat/edit.html.twig',
                array('candidat' => $candidat,
                    'edit_form' => $editForm->createView()));
    }

    public function deleteAction(Request $request, $id) {
        $candidat = $this->getCandidat($id);
        $em = $this->getDoctrine()->getManager();
        $em->remove($candidat);
        $em->flush();
        return $this->redirectToRoute('candidat_index');
    }


    private function getCandidat($id) { // retourne l'objet candidat à partir de son id
        $repository = $this->getDoctrine()->getManager()
            ->getRepository('ElectionBundle:Candidat');
        $candidat = $repository->find($id);
        if ($candidat == null)
            throw $this->createNotFoundException('candidat inexistant');
        return $candidat;
    }

    public function delisterAction($id){
        $candidats=$this->getCandidat($id);
        $liste=$candidats->getListe();
        $candidats->setListe(null);
        /*$liste->removeCandidat($candidats);*/
        $this->getDoctrine()->getManager()->flush();
        return $this->redirectToRoute('liste_show',array('id'=>$liste->getId()));
    }

    public function attacherAction($idcandidat,$idliste){
        $candidats=$this->getCandidat($idcandidat);
        $em = $this->getDoctrine()->getManager();
        $liste=$em->getRepository('ElectionBundle:Liste')->find($idliste);
        $candidats->setListe($liste);
        /*$liste->removeCandidat($candidats);*/
        $em->flush();
        return $this->redirectToRoute('liste_show',array('id'=>$liste->getId()));
    }

    public function rechercheAction(Request $request,$nom=""){
        $candidat=new Candidat();
        $candidat->setNom($nom);
        $em = $this->getDoctrine()->getManager();
        $candidats=$em->getRepository('ElectionBundle:Candidat')->recherche($nom);
        $form = $this->createFormBuilder($candidat)->add('nom', TextType::class)
            ->add('Valider',SubmitType::class)->getForm();
        $form->handleRequest($request);
        if($form->isSubmitted()){
            return $this->redirectToRoute('candidat_recherche',
                array('nom' => $candidat->getNom()));

        }
        return $this->render('@Election/Candidat/recherche.html.twig',
            array('candidats' => $candidats,
                'form' => $form->createView()));
    }


}
