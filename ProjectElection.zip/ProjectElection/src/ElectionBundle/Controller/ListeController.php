<?php

namespace ElectionBundle\Controller;

use ElectionBundle\Entity\Liste;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;

class ListeController extends Controller
{
    public function indexAction(){
        $em= $this->getDoctrine()->getManager();
        $listes = $em->getRepository('ElectionBundle:Liste')->findAll();
        return $this->render('@Election/Liste/index.html.twig', array('listes'=>$listes));
    }

    public function newAction(Request $request) {
        $liste = new Liste();
        $form = $this->createForm('ElectionBundle\Form\ListeType', $liste);
        $form->handleRequest($request);
        if ($form->isSubmitted() && $form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->persist($liste);
            $em->flush();
            return $this->redirectToRoute('liste_show',
                    array('id' => $liste->getId()));
        }
        return $this->render('@Election/Liste/new.html.twig',
                array('liste' => $liste,'form' => $form->createView()));
    }

    public function showAction($id) {
        $liste = $this->getListe($id);
        return $this->render('@Election/Liste/show.html.twig',
                array('liste' => $liste,'candidats'=>$liste->getCandidats()));
    }

    private function getListe($id) {
        // retourne l'entité liste à partir de son id
        $repository = $this->getDoctrine()->getManager()
            ->getRepository('ElectionBundle:Liste');
        $liste = $repository->find($id);
        if ($liste == null)
            throw $this->createNotFoundException('liste inexistant');
        return $liste;
    }

    public function editAction(Request $request, $id) {
        $liste = $this->getListe($id);
        $editForm = $this->createForm('ElectionBundle\Form\ListeType', $liste);
        $editForm->handleRequest($request);
        if ($editForm->isSubmitted() && $editForm->isValid()) {
            $this->getDoctrine()->getManager()->flush();
            return $this->redirectToRoute('liste_edit', array('id' => $id));
        }
        return $this->render('@Election/Liste/edit.html.twig',
                array('liste' => $liste, 'edit_form' => $editForm->createView()));
    }

    public function deleteAction(Request $request, $id) {
        $liste = $this->getListe($id);
        $em = $this->getDoctrine()->getManager();
        $em->remove($liste);
        $em->flush();
        return $this->redirectToRoute('liste_index');
    }

    public function proportionAction($id){
        $liste=$this->getListe($id);
        $ordis= $liste->getCandidats();
        $nb = count($ordis);
        $nbm=0;
        $nbf=0;
        foreach($ordis as $ordi){
            if($ordi->getSexe()=='M')
                $nbm+=1;
            if($ordi->getSexe()=='F')
                $nbf+=1;
        }
        $nbm=($nbm/$nb)*100;
        $nbf=($nbf/$nb)*100;
        return $this->render('@Election/Liste/proportion.html.twig',
            array('liste' => $liste, 'nbm' => $nbm, 'nbf'=>$nbf, 'nb'=>$nb));
    }




}
