<?php
namespace ElectionBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;


class CandidatType extends AbstractType{
    public function buildForm(FormBuilderInterface $builder, array $options){
        $builder->add('nom')
            ->add('sexe')
            ->add('age')
            ->add('liste');


    }

    public function configureOption(OptionsResolver $resolver){
        $resolver->setDefaults(array('data_class' => 'ElectionBundle\Entity\Candidat'));
    }

    public function getBlockPrefix() {
        return 'electionbundle_candidat';
    }


}