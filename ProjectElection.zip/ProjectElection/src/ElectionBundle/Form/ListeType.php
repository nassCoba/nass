<?php
namespace ElectionBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;


class ListeType extends AbstractType{
    public function buildForm(FormBuilderInterface $builder, array $options){
        $builder->add('nom');


    }

    public function configureOption(OptionsResolver $resolver){
        $resolver->setDefaults(array('data_class' => 'ElectionBundle\Entity\Liste'));
    }

    public function getBlockPrefix() {
        return 'electionbundle_candidat';
    }


}