vous devez creer un localhost sur ce projet et cliquer sur ce lien:
http://127.0.0.1:8000/page_accueuil.php
