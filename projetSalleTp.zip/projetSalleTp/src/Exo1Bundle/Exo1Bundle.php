<?php

namespace Exo1Bundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class Exo1Bundle extends Bundle
{
}
