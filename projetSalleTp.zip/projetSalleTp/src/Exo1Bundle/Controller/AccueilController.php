<?php
	namespace Exo1Bundle\Controller;
	use Symfony\Bundle\FrameworkBundle\Controller\Controller;
	use Symfony\Component\HttpFoundation\Response;
	class AccueilController extends Controller{
		public function accueilAction(){
			return $this->render('@Exo1/acceuil/accueil.html.twig');
		}
		
	}