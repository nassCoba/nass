<?php

namespace SalleTpBundle\Tests\Controller;

use Symfony\Bundle\FrameworkBundle\Test\WebTestCase;

class EssaiControllerTest extends WebTestCase
{
}
