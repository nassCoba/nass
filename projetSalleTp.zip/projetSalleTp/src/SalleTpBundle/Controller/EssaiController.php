<?php

namespace SalleTpBundle\Controller;

use SalleTpBundle\Entity\Ordinateur;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use SalleTpBundle\Entity\Salle;
use Symfony\Component\HttpFoundation\Response;
use Doctrine\Common\Util\Debug;

class EssaiController extends Controller
{
    public function test1Action() {
            $entityManager = $this->getDoctrine()->getManager();
            $salle = new Salle;
            $salle->setBatiment('D');
            $salle->setEtage(7);
            $salle->setNumero(70);
            $entityManager->persist($salle);
                $result = 'persist –­­         '.$salle.' id :'.$salle->getId().'<br />';
            $entityManager->flush();
            $result .= 'flush –­­             id:'.$salle->getId().'<br />';
            $repositorySalle = $entityManager->getRepository('SalleTpBundle:Salle');
            $salle2 = $repositorySalle->find($salle->getId());
            if($salle2 !== null)
                $result .= 'find('.$salle->getId().') –­­'.$salle2;
            return new Response('<html><body>'.$result.'</body></html>');

    }

    public function test2Action() {
        $entityManager = $this->getDoctrine()->getManager();
        $salle = new Salle;
        $salle->setBatiment('D');
        $salle->setEtage(7);
        $salle->setNumero(73);
        $entityManager->persist($salle);
        $salle->setNumero($salle->getNumero()+1);
        $entityManager->flush();
        $repositorySalle = $entityManager->getRepository('SalleTpBundle:Salle');
        $salle2 = $repositorySalle->find($salle->getId());
        return new Response('<html><body>'.$salle2.'</body></html>');

    }

    public function test3Action() {
        $entityManager = $this->getDoctrine()->getManager();
        $salle = new Salle;
        $salle->setBatiment('D');
        $salle->setEtage(7);
        $salle->setNumero(75);
        $entityManager->persist($salle);
        $result = 'persist –­­         '.$salle.'<br />';
        $entityManager->flush();
        $id= $salle->getId();
        $result .= 'flush  id:'.$id.'   --- contains: '.$entityManager->contains($salle).'<br />';
        $entityManager->clear();
        $result .= 'clear  id:'.$id.'   --- contains: '.$entityManager->contains($salle).'<br />';
        $repositorySalle = $entityManager->getRepository('SalleTpBundle:Salle');
        $salle = $repositorySalle->find($salle->getId());
            $result .= 'find('.$id.') –­­ contains(cette salle): '.$entityManager->contains($salle).'<br />';
        return new Response('<html><body>'.$result.'</body></html>');

    }

    public function test4Action() {
        $entityManager = $this->getDoctrine()->getManager();
        $salle = new Salle;
        $salle->setBatiment('D');
        $salle->setEtage(7);
        $salle->setNumero(76);
        $entityManager->persist($salle);
        $result = 'persist –­­         '.$salle.'<br />';
        $entityManager->flush();
        $id= $salle->getId();
        $result .= 'flush ------ id:'.$id.'<br />';
        $repositorySalle = $entityManager->getRepository('SalleTpBundle:Salle');
        $salle = $repositorySalle->find($salle->getId());
        $result .= 'find('.$id.') –­­- salle'.$salle.'<br />';
        $entityManager->remove($salle);
        $entityManager->flush();
        $result .= 'remove salle puis flush <br/>';
        $result .= 'find('.$id.')  = '.$repositorySalle->find($id).'<br />';
        $result .= 'contains(salle) : '.$entityManager->contains($salle);
        return new Response('<html><body>'.$result.'</body></html>');

    }

    public function test6Action(){
        $repository = $this->getDoctrine()->getManager()->getRepository('SalleTpBundle:Salle');
        $salle = $repository->find(1);
        Debug::dump($salle);
        return new Response('<html><body></body></html>');
    }

    public function test7Action(){
        $repository = $this->getDoctrine()->getManager()->getRepository('SalleTpBundle:Salle');
        $listeSalles = $repository->findAll();

        return $this->render('@SalleTp/Salle/liste.html.twig', array('listeSalles' =>$listeSalles));
    }

    public function test8Action(){
        $repository = $this->getDoctrine()->getManager()->getRepository('SalleTpBundle:Salle');
        $listeSalles = $repository->findBy(array('etage'=>1),array('numero'=>'asc'),2 ,1);

        return $this->render('@SalleTp/Salle/liste.html.twig', array('listeSalles' =>$listeSalles));
    }

    public function test9Action(){
        $repository = $this->getDoctrine()->getManager()->getRepository('SalleTpBundle:Salle');
        $salle = $repository->findOneBy(array('etage'=>1));

        return new Response('<html><body>'.$salle.'</body></html>');
    }

    public function test10Action(){
        $repository = $this->getDoctrine()->getManager()->getRepository('SalleTpBundle:Salle');
        $listeSalles = $repository->findByBatiment('B');

        return $this->render('@SalleTp/Salle/liste.html.twig', array('listeSalles' =>$listeSalles));
    }

    public function test11Action(){
        $repository = $this->getDoctrine()->getManager()->getRepository('SalleTpBundle:Salle');
        $salle = $repository->findOneByEtage(1);

        return new Response('<html><body>'.$salle.'</body></html>');
    }

    public function test12Action(){
        $repository = $this->getDoctrine()->getManager()->getRepository('SalleTpBundle:Salle');
        $listeSalles = $repository->findByBatimentAndEtageMax('D',6);

        return $this->render('@SalleTp/Salle/liste.html.twig', array('listeSalles' =>$listeSalles));
    }

    public function test13Action(){
        $repository = $this->getDoctrine()->getManager()->getRepository('SalleTpBundle:Salle');
        $listeSalles = $repository->FindSalleBatAouB();

        return $this->render('@SalleTp/Salle/liste.html.twig', array('listeSalles' =>$listeSalles));
    }

    public function test14Action(){
        $repository = $this->getDoctrine()->getManager()->getRepository('SalleTpBundle:Salle');
        $result = $repository->plusUnEtage();

        return new Response('<html><body><a href="http://localhost/phpmyadmin"> voir phpmyadmin</a></body></html>');
    }


    public function test16Action(){
        $repository = $this->getDoctrine()->getManager()->getRepository('SalleTpBundle:Salle');
        $result = $repository->testGetResult();

        Debug::dump($result);

        return new Response('<html><body></body></html>');
    }

    public function test19Action(){
        $repository = $this->getDoctrine()->getManager()->getRepository('SalleTpBundle:Salle');
        $result = $repository->testGetSingleScalarResult();

        Debug::dump($result);

        return new Response('<html><body></body></html>');
    }

    public function test23Action(){
        $entityManager = $this->getDoctrine()->getManager();
        $salle = new Salle;
        $salle->setBatiment('b');
        $salle->setEtage(3);
        $salle->setNumero(63);
        $entityManager->persist($salle);
        $entityManager->flush();
        return $this->redirectToRoute('salle_tp_voir2', array('id' => $salle->getId()));
    }

    public  function test25Action(){
        $entityManager = $this->getDoctrine()->getManager();
        $ordi = new Ordinateur;
        $ordi->setNumero(702);
        $ordi->setIp('192.168.7.02');
        $repository = $this->getDoctrine()->getManager()->getRepository('SalleTpBundle:Salle');
        $salle = $repository->findOneBy(array('batiment'=>'B','etage'=>3,'numero'=>63));
        $ordi->setSalle($salle);
        $entityManager->persist($ordi);
        $entityManager->flush();


        Debug::dump($ordi);

        return new Response('<html><body></body></html>');

    }

    public  function test26Action(){
        $entityManager = $this->getDoctrine()->getManager();
        $ordi = new Ordinateur;
        $ordi->setNumero(701);
        $ordi->setIp('192.168.7.01');
        $salle= new Salle;
        $salle->setBatiment('D');
        $salle->setEtage(7);
        $salle->setNumero(01);
        $ordi->setSalle($salle);
        $entityManager->persist($ordi);
        $entityManager->persist($salle);
        $entityManager->flush();


        Debug::dump($ordi);
        return new Response('<html><body></body></html>');

    }

    public  function test27Action(){
        $entityManager = $this->getDoctrine()->getManager();
        $ordi = new Ordinateur;
        $ordi->setNumero(703);
        $ordi->setIp('192.168.7.03');
        $salle= new Salle;
        $salle->setBatiment('D');
        $salle->setEtage(7);
        $salle->setNumero(03);
        $ordi->setSalle($salle);
        $entityManager->persist($ordi);
        $entityManager->flush();


        Debug::dump($ordi);
        return new Response('<html><body></body></html>');

    }

    public function test28Action(){
        $repositoryOrdinateur = $this->getDoctrine()->getManager()->getRepository('SalleTpBundle:Ordinateur');
        $ordi = $repositoryOrdinateur->findOneByNumero(703);
        return new Response('<html><body>'.$ordi->getSalle()->getBatiment().'</body></html>');
    }

    public  function test29Action(){
        $entityManager = $this->getDoctrine()->getManager();
        $ordi = new Ordinateur;
        $ordi->setNumero(803);
        $ordi->setIp('192.168.8.03');
        $salle= new Salle;
        $salle->setBatiment('D');
        $salle->setEtage(8);
        $salle->setNumero(03);
        $salle->addOrdinateur($ordi);
        $entityManager->persist($ordi);
        $entityManager->flush();


        Debug::dump($ordi);
        return new Response('<html><body></body></html>');

    }

    public  function test30Action(){
        $entityManager = $this->getDoctrine()->getManager();
        $ordi = new Ordinateur;
        $ordi->setNumero(804);
        $ordi->setIp('192.168.8.04');
        $salle= new Salle;
        $salle->setBatiment('D');
        $salle->setEtage(8);
        $salle->setNumero(04);
        $ordi->setSalle($salle);
        $entityManager->persist($ordi);
        $entityManager->flush();


        Debug::dump($ordi);
        return new Response('<html><body></body></html>');

    }

    public  function test31Action(){
        $entityManager = $this->getDoctrine()->getManager();
        $ordi = new Ordinateur;
        $ordi->setNumero(900);
        $ordi->setIp('192.168.8.00');
        $salle= new Salle;
        $salle->setBatiment('D');
        $salle->setEtage(8);
        $salle->setNumero(10);
        $salle->addOrdinateur($ordi);
        $entityManager->persist($salle);
        $entityManager->flush();


        Debug::dump($salle);
        return new Response('<html><body></body></html>');

    }
}

