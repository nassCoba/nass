<?php

namespace SalleTpBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class SalleTpBundle extends Bundle
{
}
