<?php

	namespace ExoPetsBundle\Controller;
	use ExoPetsBundle\Entity\Animal;
	use Symfony\Bundle\FrameworkBundle\Controller\Controller;
	use Symfony\Component\HttpFoundation\Response;
	use Symfony\Component\HttpFoundation\Request;
	use Symfony\Component\Form\Extension\Core\Type\TextType;
	use Symfony\Component\Form\Extension\Core\Type\SubmitType;
	use Symfony\Component\Form\Extension\Core\Type\DateType;
	use Symfony\Component\Form\Extension\Core\Type\NumberType;
    use ExoPetsBundle\Form\AnimalType;
	
	class ExoPetsController extends Controller {
		
		public function ajouterAction(Request $request){
			$animal = new Animal;
            $form = $this->createForm(AnimalType::class, $animal, array('action' => $this->generateUrl('exo_pets_ajouter')));
            $form->add('submit', SubmitType::class, array('label' => 'Ajouter'));
            $form->handleRequest($request);

            if($form->isSubmitted() && $form->isValid()){
                $entityManager = $this->getDoctrine()->getManager();
                $entityManager->persist($animal);
                $entityManager->flush();
                $url = $this->generateUrl('exo_pets_tous');
                return $this->redirect($url);
            }

			return $this->render('@ExoPets/Zoo/ajouter.html.twig', array('monFormulaire' => $form->createView()));
		}
		
		
		public function achat_client_voirAction($id){
			$repository = $this->getDoctrine()->getManager()->getRepository('ExoPetsBundle:Animal');
			$animal = $repository->find($id);
			if($animal == null)
				throw $this->createNotFoundException('Animal[id='.$id.'] inexistante');
			return $this->render('@ExoPets/Zoo/achat_client_voir.html.twig', array('animal' => $animal));
		}
		
		public function tousAction(){
                        $repository = $this->getDoctrine()->getManager()->getRepository('ExoPetsBundle:Animal');
                        $animaux = $repository->findAll();
                        return $this->render('@ExoPets/Zoo/animaux.html.twig',
				array('animaux' => $animaux));
		}
	}
