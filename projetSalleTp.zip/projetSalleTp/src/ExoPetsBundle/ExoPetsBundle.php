<?php

namespace ExoPetsBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ExoPetsBundle extends Bundle
{
}
