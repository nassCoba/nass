<?php
namespace ExoPetsBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;


class AnimalType extends AbstractType{
    public function buildForm(FormBuilderInterface $builder, array $options){
        $builder->add('nom')
            ->add('poids')
            ->add('dateNaissance');

    }

    public function configureOption(OptionsResolver $resolver){
        $resolver->setDefaults(array('data_class' => 'ExoPetsBundle\Entity\Animal'));
    }

}