<?php

/* @SalleTp/Salle/treize.html.twig */
class __TwigTemplate_9eedeed2a4a2ce64c336d82a35f2a4c926b3ae8f45a9616ee7273c2656f2e959 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@SalleTp/Salle/treize.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@SalleTp/Salle/treize.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
\t<html>
\t\t<head>
\t\t\t<title>Accueil</title>
\t\t</head>
\t\t<body>
\t\t\t<ul>
\t\t\t\t<li>batiment ";
        // line 8
        echo twig_escape_filter($this->env, $this->getAttribute(($context["salle"] ?? $this->getContext($context, "salle")), "batiment", array()), "html", null, true);
        echo "</li>
\t\t\t\t<li>etage ";
        // line 9
        echo twig_escape_filter($this->env, $this->getAttribute(($context["salle"] ?? $this->getContext($context, "salle")), "etage", array()), "html", null, true);
        echo "</li>
\t\t\t\t<li>numero ";
        // line 10
        echo twig_escape_filter($this->env, $this->getAttribute(($context["salle"] ?? $this->getContext($context, "salle")), "numero", array()), "html", null, true);
        echo "</li>
\t\t\t</ul>
\t\t</body>
\t</html>";
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "@SalleTp/Salle/treize.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  42 => 10,  38 => 9,  34 => 8,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
\t<html>
\t\t<head>
\t\t\t<title>Accueil</title>
\t\t</head>
\t\t<body>
\t\t\t<ul>
\t\t\t\t<li>batiment {{ salle.batiment }}</li>
\t\t\t\t<li>etage {{ salle.etage }}</li>
\t\t\t\t<li>numero {{ salle.numero }}</li>
\t\t\t</ul>
\t\t</body>
\t</html>", "@SalleTp/Salle/treize.html.twig", "/home/nass/cour/projetSalleTp/src/SalleTpBundle/Resources/views/Salle/treize.html.twig");
    }
}
