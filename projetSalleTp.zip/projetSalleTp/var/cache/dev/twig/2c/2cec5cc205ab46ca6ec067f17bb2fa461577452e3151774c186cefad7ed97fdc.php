<?php

/* @SalleTp/Salle/voir.html.twig */
class __TwigTemplate_f5fd55b94f0a5956840bb2f133d9a29e1d61b8dd3f1a2fd68244ca6b4a5b65f5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@SalleTp/Salle/voir.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@SalleTp/Salle/voir.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
\t<html>
\t\t<head>
\t\t\t<title>Accueil</title>
\t\t</head>
\t\t<body>
\t\t\t<img src=\"/images/upjv.jpg\" />
\t\t\t<h1>Salle ";
        // line 8
        echo twig_escape_filter($this->env, ($context["numero"] ?? $this->getContext($context, "numero")), "html", null, true);
        echo " </h1>
\t\t\t<p> Voici quelques information concernant les salles<br \\>
\t\t\tle petit nasser ";
        // line 10
        echo twig_escape_filter($this->env, ($context["numero"] ?? $this->getContext($context, "numero")), "html", null, true);
        echo " est un grand feneant d'ordre numero 1<br \\>
\t\t\tblablakld skdjkdkk
\t\t\t</p>
\t\t</body>
\t</html>";
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "@SalleTp/Salle/voir.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  39 => 10,  34 => 8,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
\t<html>
\t\t<head>
\t\t\t<title>Accueil</title>
\t\t</head>
\t\t<body>
\t\t\t<img src=\"/images/upjv.jpg\" />
\t\t\t<h1>Salle {{numero}} </h1>
\t\t\t<p> Voici quelques information concernant les salles<br \\>
\t\t\tle petit nasser {{ numero }} est un grand feneant d'ordre numero 1<br \\>
\t\t\tblablakld skdjkdkk
\t\t\t</p>
\t\t</body>
\t</html>", "@SalleTp/Salle/voir.html.twig", "/home/nass/cour/projetSalleTp/src/SalleTpBundle/Resources/views/Salle/voir.html.twig");
    }
}
