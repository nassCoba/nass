<?php

use Symfony\Component\Routing\Exception\MethodNotAllowedException;
use Symfony\Component\Routing\Exception\ResourceNotFoundException;
use Symfony\Component\Routing\RequestContext;

/**
 * This class has been auto-generated
 * by the Symfony Routing Component.
 */
class appDevDebugProjectContainerUrlMatcher extends Symfony\Bundle\FrameworkBundle\Routing\RedirectableUrlMatcher
{
    public function __construct(RequestContext $context)
    {
        $this->context = $context;
    }

    public function match($rawPathinfo)
    {
        $allow = array();
        $pathinfo = rawurldecode($rawPathinfo);
        $trimmedPathinfo = rtrim($pathinfo, '/');
        $context = $this->context;
        $request = $this->request ?: $this->createRequest($pathinfo);
        $requestMethod = $canonicalMethod = $context->getMethod();

        if ('HEAD' === $requestMethod) {
            $canonicalMethod = 'GET';
        }

        if (0 === strpos($pathinfo, '/_')) {
            // _wdt
            if (0 === strpos($pathinfo, '/_wdt') && preg_match('#^/_wdt/(?P<token>[^/]++)$#sD', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => '_wdt')), array (  '_controller' => 'web_profiler.controller.profiler:toolbarAction',));
            }

            if (0 === strpos($pathinfo, '/_profiler')) {
                // _profiler_home
                if ('/_profiler' === $trimmedPathinfo) {
                    $ret = array (  '_controller' => 'web_profiler.controller.profiler:homeAction',  '_route' => '_profiler_home',);
                    if ('/' === substr($pathinfo, -1)) {
                        // no-op
                    } elseif ('GET' !== $canonicalMethod) {
                        goto not__profiler_home;
                    } else {
                        return array_replace($ret, $this->redirect($rawPathinfo.'/', '_profiler_home'));
                    }

                    return $ret;
                }
                not__profiler_home:

                if (0 === strpos($pathinfo, '/_profiler/search')) {
                    // _profiler_search
                    if ('/_profiler/search' === $pathinfo) {
                        return array (  '_controller' => 'web_profiler.controller.profiler:searchAction',  '_route' => '_profiler_search',);
                    }

                    // _profiler_search_bar
                    if ('/_profiler/search_bar' === $pathinfo) {
                        return array (  '_controller' => 'web_profiler.controller.profiler:searchBarAction',  '_route' => '_profiler_search_bar',);
                    }

                }

                // _profiler_phpinfo
                if ('/_profiler/phpinfo' === $pathinfo) {
                    return array (  '_controller' => 'web_profiler.controller.profiler:phpinfoAction',  '_route' => '_profiler_phpinfo',);
                }

                // _profiler_search_results
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/search/results$#sD', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_search_results')), array (  '_controller' => 'web_profiler.controller.profiler:searchResultsAction',));
                }

                // _profiler_open_file
                if ('/_profiler/open' === $pathinfo) {
                    return array (  '_controller' => 'web_profiler.controller.profiler:openAction',  '_route' => '_profiler_open_file',);
                }

                // _profiler
                if (preg_match('#^/_profiler/(?P<token>[^/]++)$#sD', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler')), array (  '_controller' => 'web_profiler.controller.profiler:panelAction',));
                }

                // _profiler_router
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/router$#sD', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_router')), array (  '_controller' => 'web_profiler.controller.router:panelAction',));
                }

                // _profiler_exception
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/exception$#sD', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_exception')), array (  '_controller' => 'web_profiler.controller.exception:showAction',));
                }

                // _profiler_exception_css
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/exception\\.css$#sD', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_exception_css')), array (  '_controller' => 'web_profiler.controller.exception:cssAction',));
                }

            }

            // _twig_error_test
            if (0 === strpos($pathinfo, '/_error') && preg_match('#^/_error/(?P<code>\\d+)(?:\\.(?P<_format>[^/]++))?$#sD', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => '_twig_error_test')), array (  '_controller' => 'twig.controller.preview_error:previewErrorPageAction',  '_format' => 'html',));
            }

        }

        // exo_pets_homepage
        if ('/pets' === $trimmedPathinfo) {
            $ret = array (  '_controller' => 'ExoPetsBundle\\Controller\\DefaultController::indexAction',  '_route' => 'exo_pets_homepage',);
            if ('/' === substr($pathinfo, -1)) {
                // no-op
            } elseif ('GET' !== $canonicalMethod) {
                goto not_exo_pets_homepage;
            } else {
                return array_replace($ret, $this->redirect($rawPathinfo.'/', 'exo_pets_homepage'));
            }

            return $ret;
        }
        not_exo_pets_homepage:

        if (0 === strpos($pathinfo, '/pets/a')) {
            // exo_pets_achat_client_voir
            if (0 === strpos($pathinfo, '/pets/achat/client/voir') && preg_match('#^/pets/achat/client/voir/(?P<id>[^/]++)$#sD', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => 'exo_pets_achat_client_voir')), array (  '_controller' => 'ExoPetsBundle\\Controller\\ExoPetsController::achat_client_voirAction',));
            }

            // exo_pets_ajouter
            if ('/pets/animal/ajouter' === $pathinfo) {
                return array (  '_controller' => 'ExoPetsBundle\\Controller\\ExoPetsController::ajouterAction',  '_route' => 'exo_pets_ajouter',);
            }

            // exo_pets_tous
            if ('/pets/animal/tous' === $pathinfo) {
                return array (  '_controller' => 'ExoPetsBundle\\Controller\\ExoPetsController::tousAction',  '_route' => 'exo_pets_tous',);
            }

        }

        // exo1_homepage
        if ('/exo' === $trimmedPathinfo) {
            $ret = array (  '_controller' => 'Exo1Bundle\\Controller\\DefaultController::indexAction',  '_route' => 'exo1_homepage',);
            if ('/' === substr($pathinfo, -1)) {
                // no-op
            } elseif ('GET' !== $canonicalMethod) {
                goto not_exo1_homepage;
            } else {
                return array_replace($ret, $this->redirect($rawPathinfo.'/', 'exo1_homepage'));
            }

            return $ret;
        }
        not_exo1_homepage:

        if (0 === strpos($pathinfo, '/exo/exo')) {
            // exo1_accueil
            if ('/exo/exo' === $trimmedPathinfo) {
                $ret = array (  '_controller' => 'Exo1Bundle\\Controller\\AccueilController::accueilAction',  '_route' => 'exo1_accueil',);
                if ('/' === substr($pathinfo, -1)) {
                    // no-op
                } elseif ('GET' !== $canonicalMethod) {
                    goto not_exo1_accueil;
                } else {
                    return array_replace($ret, $this->redirect($rawPathinfo.'/', 'exo1_accueil'));
                }

                return $ret;
            }
            not_exo1_accueil:

            // exo1_nombre
            if ('/exo/exo/nombre' === $pathinfo) {
                return array (  '_controller' => 'Exo1Bundle\\Controller\\AccueilController::nombreAction',  '_route' => 'exo1_nombre',);
            }

        }

        elseif (0 === strpos($pathinfo, '/salle')) {
            // salle_tp_homepage
            if ('/salle' === $trimmedPathinfo) {
                $ret = array (  '_controller' => 'SalleTpBundle\\Controller\\DefaultController::indexAction',  '_route' => 'salle_tp_homepage',);
                if ('/' === substr($pathinfo, -1)) {
                    // no-op
                } elseif ('GET' !== $canonicalMethod) {
                    goto not_salle_tp_homepage;
                } else {
                    return array_replace($ret, $this->redirect($rawPathinfo.'/', 'salle_tp_homepage'));
                }

                return $ret;
            }
            not_salle_tp_homepage:

            // salle_tp_accueil
            if ('/salle/accueil' === $pathinfo) {
                return array (  '_controller' => 'SalleTpBundle\\Controller\\SalleController::accueilAction',  '_route' => 'salle_tp_accueil',);
            }

            if (0 === strpos($pathinfo, '/salle/ajouter')) {
                // salle_tp_ajouter
                if (preg_match('#^/salle/ajouter/(?P<batiment>A|B|C|D)\\-(?P<etage>\\d+)\\.(?P<numero>\\d{1,2})$#sD', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'salle_tp_ajouter')), array (  '_controller' => 'SalleTpBundle\\Controller\\SalleController::ajouterAction',));
                }

                // salle_tp_ajouter2
                if ('/salle/ajouter2' === $pathinfo) {
                    return array (  '_controller' => 'SalleTpBundle\\Controller\\SalleController::ajouter2Action',  '_route' => 'salle_tp_ajouter2',);
                }

            }

            elseif (0 === strpos($pathinfo, '/salle/voir')) {
                // salle_tp_voir
                if (preg_match('#^/salle/voir/(?P<numero>\\d{1,2})$#sD', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'salle_tp_voir')), array (  '_controller' => 'SalleTpBundle\\Controller\\SalleController::voirAction',));
                }

                // salle_tp_voir2
                if (0 === strpos($pathinfo, '/salle/voir2') && preg_match('#^/salle/voir2/(?P<id>\\d+)$#sD', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'salle_tp_voir2')), array (  '_controller' => 'SalleTpBundle\\Controller\\SalleController::voir2Action',));
                }

            }

            elseif (0 === strpos($pathinfo, '/salle/treize')) {
                // salle_tp_treize
                if ('/salle/treize' === $pathinfo) {
                    return array (  '_controller' => 'SalleTpBundle\\Controller\\SalleController::treizeAction',  '_route' => 'salle_tp_treize',);
                }

                // salle_tp_treize_bis
                if ('/salle/treizebis' === $pathinfo) {
                    return array (  '_controller' => 'SalleTpBundle\\Controller\\SalleController::treize_bisAction',  '_route' => 'salle_tp_treize_bis',);
                }

            }

            elseif (0 === strpos($pathinfo, '/salle/modifier')) {
                // salle_tp_modifier
                if (preg_match('#^/salle/modifier/(?P<id>\\d+)$#sD', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'salle_tp_modifier')), array (  '_controller' => 'SalleTpBundle\\Controller\\SalleController::modifierAction',));
                }

                // salle_tp_modifier_suite
                if (0 === strpos($pathinfo, '/salle/modifierSuite') && preg_match('#^/salle/modifierSuite/(?P<id>[^/]++)$#sD', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'salle_tp_modifier_suite')), array (  '_controller' => 'SalleTpBundle\\Controller\\SalleController::modifierSuiteAction',));
                }

                // salle_tp_modifier2
                if (0 === strpos($pathinfo, '/salle/modifier2') && preg_match('#^/salle/modifier2/(?P<id>[^/]++)$#sD', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'salle_tp_modifier2')), array (  '_controller' => 'SalleTpBundle\\Controller\\SalleController::modifier2Action',));
                }

            }

            elseif (0 === strpos($pathinfo, '/salle/essai/test')) {
                if (0 === strpos($pathinfo, '/salle/essai/test1')) {
                    // salle_tp_test1
                    if ('/salle/essai/test1' === $pathinfo) {
                        return array (  '_controller' => 'SalleTpBundle\\Controller\\EssaiController::test1Action',  '_route' => 'salle_tp_test1',);
                    }

                    // salle_tp_test10
                    if ('/salle/essai/test10' === $pathinfo) {
                        return array (  '_controller' => 'SalleTpBundle\\Controller\\EssaiController::test10Action',  '_route' => 'salle_tp_test10',);
                    }

                    // salle_tp_test11
                    if ('/salle/essai/test11' === $pathinfo) {
                        return array (  '_controller' => 'SalleTpBundle\\Controller\\EssaiController::test11Action',  '_route' => 'salle_tp_test11',);
                    }

                    // salle_tp_test12
                    if ('/salle/essai/test12' === $pathinfo) {
                        return array (  '_controller' => 'SalleTpBundle\\Controller\\EssaiController::test12Action',  '_route' => 'salle_tp_test12',);
                    }

                    // salle_tp_test13
                    if ('/salle/essai/test13' === $pathinfo) {
                        return array (  '_controller' => 'SalleTpBundle\\Controller\\EssaiController::test13Action',  '_route' => 'salle_tp_test13',);
                    }

                    // salle_tp_test14
                    if ('/salle/essai/test14' === $pathinfo) {
                        return array (  '_controller' => 'SalleTpBundle\\Controller\\EssaiController::test14Action',  '_route' => 'salle_tp_test14',);
                    }

                    // salle_tp_test15
                    if ('/salle/essai/test15' === $pathinfo) {
                        return array (  '_controller' => 'SalleTpBundle\\Controller\\EssaiController::test15Action',  '_route' => 'salle_tp_test15',);
                    }

                    // salle_tp_test16
                    if ('/salle/essai/test16' === $pathinfo) {
                        return array (  '_controller' => 'SalleTpBundle\\Controller\\EssaiController::test16Action',  '_route' => 'salle_tp_test16',);
                    }

                    // salle_tp_test17
                    if ('/salle/essai/test17' === $pathinfo) {
                        return array (  '_controller' => 'SalleTpBundle\\Controller\\EssaiController::test17Action',  '_route' => 'salle_tp_test17',);
                    }

                    // salle_tp_test18
                    if ('/salle/essai/test18' === $pathinfo) {
                        return array (  '_controller' => 'SalleTpBundle\\Controller\\EssaiController::test18Action',  '_route' => 'salle_tp_test18',);
                    }

                    // salle_tp_test19
                    if ('/salle/essai/test19' === $pathinfo) {
                        return array (  '_controller' => 'SalleTpBundle\\Controller\\EssaiController::test19Action',  '_route' => 'salle_tp_test19',);
                    }

                }

                elseif (0 === strpos($pathinfo, '/salle/essai/test2')) {
                    // salle_tp_test2
                    if ('/salle/essai/test2' === $pathinfo) {
                        return array (  '_controller' => 'SalleTpBundle\\Controller\\EssaiController::test2Action',  '_route' => 'salle_tp_test2',);
                    }

                    // salle_tp_test20
                    if ('/salle/essai/test20' === $pathinfo) {
                        return array (  '_controller' => 'SalleTpBundle\\Controller\\EssaiController::test20Action',  '_route' => 'salle_tp_test20',);
                    }

                    // salle_tp_test21
                    if ('/salle/essai/test21' === $pathinfo) {
                        return array (  '_controller' => 'SalleTpBundle\\Controller\\EssaiController::test21Action',  '_route' => 'salle_tp_test21',);
                    }

                    // salle_tp_test22
                    if ('/salle/essai/test22' === $pathinfo) {
                        return array (  '_controller' => 'SalleTpBundle\\Controller\\EssaiController::test22Action',  '_route' => 'salle_tp_test22',);
                    }

                    // salle_tp_test23
                    if ('/salle/essai/test23' === $pathinfo) {
                        return array (  '_controller' => 'SalleTpBundle\\Controller\\EssaiController::test23Action',  '_route' => 'salle_tp_test23',);
                    }

                    // salle_tp_test24
                    if ('/salle/essai/test24' === $pathinfo) {
                        return array (  '_controller' => 'SalleTpBundle\\Controller\\EssaiController::test24Action',  '_route' => 'salle_tp_test24',);
                    }

                    // salle_tp_test25
                    if ('/salle/essai/test25' === $pathinfo) {
                        return array (  '_controller' => 'SalleTpBundle\\Controller\\EssaiController::test25Action',  '_route' => 'salle_tp_test25',);
                    }

                    // salle_tp_test26
                    if ('/salle/essai/test26' === $pathinfo) {
                        return array (  '_controller' => 'SalleTpBundle\\Controller\\EssaiController::test26Action',  '_route' => 'salle_tp_test26',);
                    }

                    // salle_tp_test27
                    if ('/salle/essai/test27' === $pathinfo) {
                        return array (  '_controller' => 'SalleTpBundle\\Controller\\EssaiController::test27Action',  '_route' => 'salle_tp_test27',);
                    }

                    // salle_tp_test28
                    if ('/salle/essai/test28' === $pathinfo) {
                        return array (  '_controller' => 'SalleTpBundle\\Controller\\EssaiController::test28Action',  '_route' => 'salle_tp_test28',);
                    }

                    // salle_tp_test29
                    if ('/salle/essai/test29' === $pathinfo) {
                        return array (  '_controller' => 'SalleTpBundle\\Controller\\EssaiController::test29Action',  '_route' => 'salle_tp_test29',);
                    }

                }

                elseif (0 === strpos($pathinfo, '/salle/essai/test3')) {
                    // salle_tp_test3
                    if ('/salle/essai/test3' === $pathinfo) {
                        return array (  '_controller' => 'SalleTpBundle\\Controller\\EssaiController::test3Action',  '_route' => 'salle_tp_test3',);
                    }

                    // salle_tp_test30
                    if ('/salle/essai/test30' === $pathinfo) {
                        return array (  '_controller' => 'SalleTpBundle\\Controller\\EssaiController::test30Action',  '_route' => 'salle_tp_test30',);
                    }

                    // salle_tp_test31
                    if ('/salle/essai/test31' === $pathinfo) {
                        return array (  '_controller' => 'SalleTpBundle\\Controller\\EssaiController::test31Action',  '_route' => 'salle_tp_test31',);
                    }

                    // salle_tp_test32
                    if ('/salle/essai/test32' === $pathinfo) {
                        return array (  '_controller' => 'SalleTpBundle\\Controller\\EssaiController::test32Action',  '_route' => 'salle_tp_test32',);
                    }

                    // salle_tp_test33
                    if ('/salle/essai/test33' === $pathinfo) {
                        return array (  '_controller' => 'SalleTpBundle\\Controller\\EssaiController::test33Action',  '_route' => 'salle_tp_test33',);
                    }

                    // salle_tp_test34
                    if ('/salle/essai/test34' === $pathinfo) {
                        return array (  '_controller' => 'SalleTpBundle\\Controller\\EssaiController::test34Action',  '_route' => 'salle_tp_test34',);
                    }

                    // salle_tp_test35
                    if ('/salle/essai/test35' === $pathinfo) {
                        return array (  '_controller' => 'SalleTpBundle\\Controller\\EssaiController::test35Action',  '_route' => 'salle_tp_test35',);
                    }

                    // salle_tp_test36
                    if ('/salle/essai/test36' === $pathinfo) {
                        return array (  '_controller' => 'SalleTpBundle\\Controller\\EssaiController::test36Action',  '_route' => 'salle_tp_test36',);
                    }

                    // salle_tp_test37
                    if ('/salle/essai/test37' === $pathinfo) {
                        return array (  '_controller' => 'SalleTpBundle\\Controller\\EssaiController::test37Action',  '_route' => 'salle_tp_test37',);
                    }

                    // salle_tp_test38
                    if ('/salle/essai/test38' === $pathinfo) {
                        return array (  '_controller' => 'SalleTpBundle\\Controller\\EssaiController::test38Action',  '_route' => 'salle_tp_test38',);
                    }

                    // salle_tp_test39
                    if ('/salle/essai/test39' === $pathinfo) {
                        return array (  '_controller' => 'SalleTpBundle\\Controller\\EssaiController::test39Action',  '_route' => 'salle_tp_test39',);
                    }

                }

                elseif (0 === strpos($pathinfo, '/salle/essai/test4')) {
                    // salle_tp_test4
                    if ('/salle/essai/test4' === $pathinfo) {
                        return array (  '_controller' => 'SalleTpBundle\\Controller\\EssaiController::test4Action',  '_route' => 'salle_tp_test4',);
                    }

                    // salle_tp_test40
                    if ('/salle/essai/test40' === $pathinfo) {
                        return array (  '_controller' => 'SalleTpBundle\\Controller\\EssaiController::test40Action',  '_route' => 'salle_tp_test40',);
                    }

                    // salle_tp_test41
                    if ('/salle/essai/test41' === $pathinfo) {
                        return array (  '_controller' => 'SalleTpBundle\\Controller\\EssaiController::test41Action',  '_route' => 'salle_tp_test41',);
                    }

                    if (0 === strpos($pathinfo, '/salle/essai/test42')) {
                        // salle_tp_test42
                        if ('/salle/essai/test42' === $pathinfo) {
                            return array (  '_controller' => 'SalleTpBundle\\Controller\\EssaiController::test42Action',  '_route' => 'salle_tp_test42',);
                        }

                        // salle_tp_test50
                        if ('/salle/essai/test42' === $pathinfo) {
                            return array (  '_controller' => 'SalleTpBundle\\Controller\\EssaiController::test42Action',  '_route' => 'salle_tp_test50',);
                        }

                    }

                }

                // salle_tp_test5
                if ('/salle/essai/test5' === $pathinfo) {
                    return array (  '_controller' => 'SalleTpBundle\\Controller\\EssaiController::test5Action',  '_route' => 'salle_tp_test5',);
                }

                // salle_tp_test6
                if ('/salle/essai/test6' === $pathinfo) {
                    return array (  '_controller' => 'SalleTpBundle\\Controller\\EssaiController::test6Action',  '_route' => 'salle_tp_test6',);
                }

                // salle_tp_test7
                if ('/salle/essai/test7' === $pathinfo) {
                    return array (  '_controller' => 'SalleTpBundle\\Controller\\EssaiController::test7Action',  '_route' => 'salle_tp_test7',);
                }

                if (0 === strpos($pathinfo, '/salle/essai/test8')) {
                    // salle_tp_test8
                    if ('/salle/essai/test8' === $pathinfo) {
                        return array (  '_controller' => 'SalleTpBundle\\Controller\\EssaiController::test8Action',  '_route' => 'salle_tp_test8',);
                    }

                    // salle_tp_test8bis
                    if ('/salle/essai/test8bis' === $pathinfo) {
                        return array (  '_controller' => 'SalleTpBundle\\Controller\\EssaiController::test8bisAction',  '_route' => 'salle_tp_test8bis',);
                    }

                }

                // salle_tp_test9
                if ('/salle/essai/test9' === $pathinfo) {
                    return array (  '_controller' => 'SalleTpBundle\\Controller\\EssaiController::test9Action',  '_route' => 'salle_tp_test9',);
                }

            }

        }

        // homepage
        if ('' === $trimmedPathinfo) {
            $ret = array (  '_controller' => 'AppBundle\\Controller\\DefaultController::indexAction',  '_route' => 'homepage',);
            if ('/' === substr($pathinfo, -1)) {
                // no-op
            } elseif ('GET' !== $canonicalMethod) {
                goto not_homepage;
            } else {
                return array_replace($ret, $this->redirect($rawPathinfo.'/', 'homepage'));
            }

            return $ret;
        }
        not_homepage:

        if ('/' === $pathinfo && !$allow) {
            throw new Symfony\Component\Routing\Exception\NoConfigurationException();
        }

        throw 0 < count($allow) ? new MethodNotAllowedException(array_unique($allow)) : new ResourceNotFoundException();
    }
}
